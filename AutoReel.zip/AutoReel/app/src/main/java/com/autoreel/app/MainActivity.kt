package com.autoreel.app

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.work.*
import java.io.File
import java.util.concurrent.TimeUnit

fun Context.p() = getSharedPreferences("ar", 0)
fun Context.dp(i: Int) = (i * resources.displayMetrics.density).toInt()
fun Context.flag(k: String, def: Boolean) = p().getString(k, def.toString()) == "true"
val BG = Color.parseColor("#05030D"); val CARD = Color.parseColor("#0F0A1F"); val EDGE = Color.parseColor("#55A78BFA")
val PINK = Color.parseColor("#E040FB"); val DIM = Color.parseColor("#9A8DB8"); val GREEN = Color.parseColor("#4ADE80")
val VIOLET = Color.parseColor("#7C3AED"); val CYAN = Color.parseColor("#22D3EE")
fun shape(c: Int, r: Int, stroke: Int = 0) = GradientDrawable().apply { setColor(c); cornerRadius = r.toFloat(); if (stroke != 0) setStroke(3, stroke) }
fun grad(r: Int, vararg cols: Int) = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, cols).apply { cornerRadius = r.toFloat() }
fun lp(w: Int, h: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, h, wt)

class F(val key: String, val label: String, val def: String, val kind: String = "t", val opts: List<String> = emptyList())
val SECTIONS = listOf(
    "Video" to listOf(F("niche", "Niche / topic (e.g. funny animals)", ""), F("language", "Language", "Hindi"), F("per_day", "Videos per day", "3"),
        F("aspect", "Aspect ratio (Auto = 9:16 for Shorts + Reels)", "Auto", "c", listOf("Auto", "9:16", "16:9")), F("seconds", "Length (Auto = 10s phone, 8s API)", "Auto", "c", listOf("Auto", "4", "6", "8")), F("style", "Extra style notes", ""),
        F("best_veo", "Best-quality Veo (costs more)", "false", "b")),
    "YouTube" to listOf(F("yt_vis", "Visibility after upload", "Public", "c", listOf("Public", "Unlisted", "Private"))),
    "Instagram reel settings" to listOf(
        F("ig_ai", "Add AI label (needed for realistic AI video)", "true", "b"),
        F("ig_hq", "Upload at highest quality", "true", "b"),
        F("ig_download", "Allow people to download reels", "true", "b"),
        F("ig_template", "Allow others to use reel as template", "true", "b"),
        F("ig_threads", "Also share on Threads", "true", "b"),
        F("ig_fb", "Also share on Facebook", "false", "b"),
        F("ig_story", "Also add to your story", "false", "b")),
    "Posting (advanced)" to listOf(
        F("footer", "Footer line on every caption (e.g. Follow for more)", ""),
        F("hashtags", "Hashtags per post", "5", "c", listOf("3", "5", "8", "12")),
        F("retries", "Retry a failed upload", "1", "c", listOf("0", "1", "2", "3")),
        F("gap", "Wait between platforms (seconds)", "15", "c", listOf("0", "15", "30", "60")),
        F("sched_mode", "START AUTO (schedule) uses", "API (Veo)", "c", listOf("API (Veo)", "Phone"))),
    "Floating bubble" to listOf(F("bubble", "Show floating bubble while running", "true", "b")),
    "Gemini" to listOf(F("gemini_key", "Gemini API key", "", "p")),
)

class MainActivity : Activity() {
    private val views = HashMap<String, View>()
    private lateinit var studio: ScrollView; private lateinit var settings: ScrollView
    private lateinit var video: VideoView; private lateinit var hint: TextView; private lateinit var info: TextView
    private lateinit var logV: TextView
    private lateinit var ytChip: LinearLayout; private lateinit var ytSub: TextView
    private lateinit var igChip: LinearLayout; private lateinit var igSub: TextView
    private lateinit var dot: TextView; private lateinit var stat: TextView
    private lateinit var sYt: TextView; private lateinit var sIg: TextView; private lateinit var sFail: TextView
    private lateinit var pulse: ObjectAnimator
    private val steps = ArrayList<TextView>(); private var shown: String? = null
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable { override fun run() { refresh(); h.postDelayed(this, 1000) } }
    private val YTC = intArrayOf(Color.parseColor("#FF2D2D"), Color.parseColor("#B30000"))
    private val IGC = intArrayOf(Color.parseColor("#F58529"), Color.parseColor("#DD2A7B"), Color.parseColor("#8134AF"))

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG; window.navigationBarColor = BG
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        studio = ScrollView(this).apply { addView(buildStudio()) }
        settings = ScrollView(this).apply { addView(buildSettings()); visibility = View.GONE }
        val frame = FrameLayout(this).apply { addView(studio); addView(settings) }
        val bar = LinearLayout(this).apply { setBackgroundColor(CARD); setPadding(0, dp(12), 0, dp(12)) }
        fun tab(t: String, s: Boolean) = TextView(this).apply {
            text = t; gravity = Gravity.CENTER; textSize = 14f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            setOnClickListener { save(); studio.visibility = if (s) View.VISIBLE else View.GONE; settings.visibility = if (s) View.GONE else View.VISIBLE }
        }
        bar.addView(tab("🎬  STUDIO", true), lp(0, -2, 1f)); bar.addView(tab("⚙️  SETTINGS", false), lp(0, -2, 1f))
        setContentView(LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG); addView(frame, lp(-1, 0, 1f)); addView(bar) })
        pulse = ObjectAnimator.ofFloat(dot, "alpha", 1f, 0.2f).apply { duration = 800; repeatMode = ValueAnimator.REVERSE; repeatCount = ValueAnimator.INFINITE; start() }
        paintChips()
    }

    private fun card() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)); background = shape(CARD, dp(18), EDGE) }
    private fun LinearLayout.add(v: View, w: Int = -1, hh: Int = -2, wt: Float = 0f) = addView(v, lp(w, hh, wt).apply { setMargins(dp(4), dp(6), dp(4), dp(6)) })
    private fun txt(t: String, sz: Float = 14f, c: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply { text = t; textSize = sz; setTextColor(c); if (bold) typeface = Typeface.DEFAULT_BOLD }
    private fun btn(t: String, c: Int, a: () -> Unit) = txt(t, 14f, Color.WHITE, true).apply {
        gravity = Gravity.CENTER; setPadding(0, dp(14), 0, dp(14)); background = shape(c, dp(14), EDGE); setOnClickListener { save(); a() }
    }
    private fun gbtn(t: String, vararg cols: Int, a: () -> Unit) = txt(t, 15f, Color.WHITE, true).apply {
        gravity = Gravity.CENTER; setPadding(0, dp(15), 0, dp(15)); background = grad(dp(14), *cols); setOnClickListener { save(); a() }
    }
    private fun label(t: String) = txt(t, 11f, CYAN, true).apply { setPadding(dp(6), dp(14), 0, dp(2)); letterSpacing = 0.15f }

    private fun paintChip(c: LinearLayout, sub: TextView, on: Boolean, cols: IntArray) {
        c.background = if (on) GradientDrawable(GradientDrawable.Orientation.TL_BR, cols).apply { cornerRadius = dp(18).toFloat(); setStroke(dp(2), Color.WHITE) } else shape(CARD, dp(18), EDGE)
        sub.text = if (on) "✓ SELECTED" else "TAP TO SELECT"; sub.setTextColor(if (on) Color.WHITE else DIM)
        c.alpha = if (on) 1f else 0.85f
    }
    private fun paintChips() {
        paintChip(ytChip, ytSub, flag("plat_yt", true), YTC); paintChip(igChip, igSub, flag("plat_ig", false), IGC)
    }
    private fun chip(key: String, icon: String, name: String, def: Boolean): Pair<LinearLayout, TextView> {
        val sub = txt("", 10f, DIM, true).apply { gravity = Gravity.CENTER; letterSpacing = 0.1f }
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(8), dp(16), dp(8), dp(16)) }
        c.addView(txt(icon, 28f).apply { gravity = Gravity.CENTER }); c.addView(txt(name, 16f, Color.WHITE, true).apply { gravity = Gravity.CENTER }); c.addView(sub)
        c.setOnClickListener { p().edit().putString(key, (!flag(key, def)).toString()).apply(); paintChips() }
        return c to sub
    }

    private fun buildStudio(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(40), dp(14), dp(16)) }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(ImageView(this).apply { setImageResource(R.drawable.logo); scaleType = ImageView.ScaleType.CENTER_CROP; clipToOutline = true; outlineProvider = object : android.view.ViewOutlineProvider() { override fun getOutline(v: View, o: android.graphics.Outline) { o.setOval(0, 0, v.width, v.height) } } }, lp(dp(56), dp(56)))
        val tt = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        tt.addView(txt("AutoReel", 26f, Color.WHITE, true)); tt.addView(txt("AI REEL STUDIO  •  YOUTUBE × INSTAGRAM", 10f, CYAN, true))
        head.addView(tt, lp(0, -2, 1f))
        val pill = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(6), dp(12), dp(6)); background = shape(CARD, dp(20), EDGE) }
        dot = txt("●", 12f, DIM); stat = txt("  IDLE", 11f, Color.WHITE, true); pill.addView(dot); pill.addView(stat); head.addView(pill)
        col.addView(head)

        col.add(label("POST TO"))
        val (yc, ys) = chip("plat_yt", "▶", "YouTube", true); ytChip = yc; ytSub = ys
        val (ic, isub) = chip("plat_ig", "◎", "Instagram", false); igChip = ic; igSub = isub
        val pr = LinearLayout(this); pr.add(ytChip, 0, -2, 1f); pr.add(igChip, 0, -2, 1f); col.addView(pr)
        col.add(txt("Select one or both. START posts to every selected platform.", 11f, DIM))

        col.add(label("PIPELINE"))
        val hs = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val row = LinearLayout(this)
        for ((ic2, n) in STAGES) {
            val s = txt("$ic2 $n", 11f, DIM, true).apply { gravity = Gravity.CENTER; setPadding(dp(12), dp(8), dp(12), dp(8)) }
            steps.add(s); row.addView(s, lp(-2, -2).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        hs.addView(row); col.addView(hs)

        val vc = card(); val fl = FrameLayout(this)
        video = VideoView(this); fl.addView(video, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        hint = txt("Your video appears here live", 15f, DIM).apply { gravity = Gravity.CENTER; setBackgroundColor(CARD) }; fl.addView(hint, FrameLayout.LayoutParams(-1, -1))
        vc.addView(fl, lp(-1, dp(380))); col.add(vc)
        info = txt("", 13f); val ic3 = card(); ic3.addView(info); col.add(ic3)

        val sr = LinearLayout(this)
        fun statCard(name: String, c: Int): TextView {
            val v = txt("0", 22f, c, true).apply { gravity = Gravity.CENTER }
            val k = card(); k.setGravity(Gravity.CENTER_HORIZONTAL); k.addView(v); k.addView(txt(name, 10f, DIM).apply { gravity = Gravity.CENTER })
            sr.add(k, 0, -2, 1f); return v
        }
        sYt = statCard("YOUTUBE POSTS", Color.parseColor("#FF5A5A")); sIg = statCard("INSTAGRAM POSTS", Color.parseColor("#F472B6")); sFail = statCard("FAILED", DIM)
        col.addView(sr)

        col.add(label("CONTROL"))
        col.add(gbtn("🚀  START AUTOMATION", VIOLET, PINK) { startPhone() })
        val r2 = LinearLayout(this)
        r2.add(btn("⚡ API RUN NOW", Color.parseColor("#1B1235")) {
            WorkManager.getInstance(this).enqueueUniqueWork("once", ExistingWorkPolicy.REPLACE, OneTimeWorkRequestBuilder<RunWorker>().setInputData(workDataOf("api" to true)).build())
            Toast.makeText(this, "Started, watch the Studio", Toast.LENGTH_SHORT).show()
        }, 0, -2, 1f)
        r2.add(btn("⏱ SCHEDULE", Color.parseColor("#1B1235")) { start() }, 0, -2, 1f)
        col.addView(r2)
        col.add(btn("■  STOP EVERYTHING", Color.parseColor("#4A1220")) { stopAll() })

        col.add(label("SHARE LAST VIDEO"))
        val r3 = LinearLayout(this)
        r3.add(gbtn("▶ YouTube", *YTC) { Share.toYouTube(this) }, 0, -2, 1f)
        r3.add(gbtn("◎ Instagram", *IGC) { Share.toInstagram(this) }, 0, -2, 1f)
        col.addView(r3)

        col.add(label("SETUP"))
        col.add(btn("♿  1) Enable Accessibility (once)", Color.parseColor("#1B1235")) { startActivity(android.content.Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        col.add(btn("🔋  2) Allow background running", Color.parseColor("#1B1235")) { startActivity(android.content.Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, android.net.Uri.parse("package:$packageName"))) })

        col.add(label("LIVE LOG"))
        logV = txt("", 11f, DIM).apply { typeface = Typeface.MONOSPACE }; val lc = card(); lc.addView(logV); col.add(lc)
        return col
    }

    private fun buildSettings(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(40), dp(14), dp(16)) }
        col.addView(txt("Settings", 26f, Color.WHITE, true))
        for ((title, fields) in SECTIONS) {
            col.add(label(title.uppercase()))
            val c = card()
            for (f in fields) {
                val saved = p().getString(f.key, f.def)!!
                when (f.kind) {
                    "b" -> c.add(CheckBox(this).apply { text = f.label; setTextColor(Color.WHITE); isChecked = saved == "true"; views[f.key] = this })
                    "c" -> {
                        c.add(txt(f.label, 12f, DIM))
                        c.add(TextView(this).apply {
                            gravity = Gravity.CENTER; textSize = 15f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
                            setPadding(0, dp(12), 0, dp(12)); background = shape(BG, dp(10), EDGE); tag = saved; text = "$saved   ⟳"
                            setOnClickListener { val i = f.opts.indexOf(tag as String); val n = f.opts[(i + 1) % f.opts.size]; tag = n; text = "$n   ⟳" }
                            views[f.key] = this
                        })
                    }
                    else -> {
                        c.add(txt(f.label, 12f, DIM))
                        c.add(EditText(this).apply {
                            setText(saved); setSingleLine(); setTextColor(Color.WHITE); setPadding(dp(12), dp(10), dp(12), dp(10)); background = shape(BG, dp(10), EDGE)
                            if (f.kind == "p") inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                            views[f.key] = this
                        })
                    }
                }
            }
            if (title == "Gemini") c.add(btn("🔑 TEST KEY", VIOLET) { testKey((views["gemini_key"] as EditText).text.toString().trim()) })
            col.addView(c)
        }
        col.add(txt("Gemini and Veo models are picked automatically (latest best).", 12f, DIM))
        return col
    }

    private fun testKey(k: String) {
        if (k.isEmpty()) { Toast.makeText(this, "Paste your Gemini key first", Toast.LENGTH_SHORT).show(); return }
        Toast.makeText(this, "Testing key...", Toast.LENGTH_SHORT).show()
        Thread {
            val msg = try {
                val r = Net.req("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200", "GET", mapOf("x-goog-api-key" to k))
                if (r.code == 200) "✅ Key works\nGemini: ${Models.pick(k, false, true)}\nVeo: ${Models.pick(k, true, false)}\n(Making Veo videos needs billing on the API)"
                else "❌ Key rejected (${r.code})\n" + r.text().take(150)
            } catch (e: Exception) { "❌ No internet or error: " + e.message }
            runOnUiThread { android.app.AlertDialog.Builder(this).setMessage(msg).setPositiveButton("OK", null).show() }
        }.start()
    }

    private fun noPlatform(): Boolean {
        if (!flag("plat_yt", true) && !flag("plat_ig", false)) { Toast.makeText(this, "Select YouTube and/or Instagram first", Toast.LENGTH_LONG).show(); return true }
        return false
    }

    private fun startPhone() {
        if (noPlatform()) return
        val perms = if (Build.VERSION.SDK_INT >= 33) arrayOf("android.permission.READ_MEDIA_VIDEO", "android.permission.READ_MEDIA_IMAGES") else arrayOf("android.permission.READ_EXTERNAL_STORAGE")
        if (perms.any { checkSelfPermission(it) != android.content.pm.PackageManager.PERMISSION_GRANTED }) { requestPermissions(perms, 2); Toast.makeText(this, "Allow media access, then press START again", Toast.LENGTH_LONG).show(); return }
        val s = AutoService.inst ?: run { Toast.makeText(this, "Turn ON AutoReel in Accessibility first", Toast.LENGTH_LONG).show(); return }
        s.runAll(); Toast.makeText(this, "Automation started. Use the floating bubble to hide or stop.", Toast.LENGTH_LONG).show()
    }

    private fun stopAll() {
        WorkManager.getInstance(this).cancelUniqueWork("auto"); WorkManager.getInstance(this).cancelUniqueWork("once")
        AutoService.inst?.stopRun(); Live.stage = 0
        Toast.makeText(this, "Stopped", Toast.LENGTH_SHORT).show()
    }

    private fun save() {
        val e = p().edit()
        for ((k, v) in views) e.putString(k, when (v) { is CheckBox -> v.isChecked.toString(); is EditText -> v.text.toString().trim(); else -> (v.tag as? String) ?: "" })
        e.apply()
    }

    private fun start() {
        if (noPlatform()) return
        val n = (p().getString("per_day", "3")?.toIntOrNull() ?: 3).coerceIn(1, 24)
        val req = PeriodicWorkRequestBuilder<RunWorker>(maxOf(15L, 24 * 60L / n), TimeUnit.MINUTES).setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("auto", ExistingPeriodicWorkPolicy.UPDATE, req)
        Toast.makeText(this, "Scheduled: $n videos/day (" + p().getString("sched_mode", "API (Veo)") + ")", Toast.LENGTH_SHORT).show()
    }

    private fun refresh() {
        val running = AutoService.running || Live.stage in 1..6
        stat.text = if (running) "  RUNNING" else "  IDLE"; dot.setTextColor(if (running) GREEN else DIM)
        for (i in steps.indices) { val on = Live.stage == i + 1; val done = Live.stage > i + 1
            steps[i].setTextColor(if (on) PINK else if (done) GREEN else DIM); steps[i].background = if (on) shape(CARD, dp(10), PINK) else null }
        sYt.text = p().getInt("yt_ok", 0).toString(); sIg.text = p().getInt("ig_ok", 0).toString(); sFail.text = p().getInt("fail", 0).toString()
        if (Live.info.isNotEmpty()) info.text = Live.info else if (info.text.isEmpty()) info.text = "Pick a platform and press START to see AutoReel work live."
        logV.text = p().getString("log", "")
        val v = Live.video ?: p().getString("last_video", null)
        val names = listOf("🔎 Finding viral ideas", "🧠 Writing your video", "🎬 Making the video")
        if (Live.stage in 1..3) { hint.visibility = View.VISIBLE; hint.text = names[Live.stage - 1] + "...\n\n" + ((System.currentTimeMillis() - Live.startedAt) / 1000) + " sec" }
        else if (v != null && File(v).exists()) {
            hint.visibility = View.GONE
            if (v != shown) {
                shown = v
                video.setOnPreparedListener { it.isLooping = true; video.start() }
                video.setOnErrorListener { _, _, _ -> hint.visibility = View.VISIBLE; hint.text = "Cannot play this video file"; true }
                video.setVideoPath(v)
            }
        }
        if (Live.newVideo) { Live.newVideo = false; h.postDelayed({ if (flag("plat_yt", true)) Share.toYouTube(this) else if (flag("plat_ig", false)) Share.toInstagram(this) }, 4000) }
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick); save() }
    override fun onDestroy() { pulse.cancel(); super.onDestroy() }
}
