package com.autoreel.app

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

object Share {
    const val YT = "com.google.android.youtube"
    const val IG = "com.instagram.android"

    fun intent(c: Context): Intent? {
        val p = c.p(); val f = File(p.getString("last_video", null) ?: return null)
        if (!f.exists()) return null
        val uri = FileProvider.getUriForFile(c, "com.autoreel.app.fp", f)
        return Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"; putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, p.getString("last_title", "")); putExtra(Intent.EXTRA_TITLE, p.getString("last_title", "")); putExtra(Intent.EXTRA_TEXT, p.getString("last_desc", ""))
            clipData = ClipData.newRawUri("v", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    private fun send(a: Activity, pkg: String, name: String) {
        val i = intent(a) ?: run { Toast.makeText(a, "Make a video first", Toast.LENGTH_SHORT).show(); return }
        val p = a.p()
        (a.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText(name, p.getString("last_title", "") + "\n\n" + p.getString("last_desc", "")))
        Toast.makeText(a, "Caption copied. Paste it in $name.", Toast.LENGTH_LONG).show()
        try { a.startActivity(Intent(i).setPackage(pkg)) }
        catch (e: Exception) { a.startActivity(Intent.createChooser(i, "Upload via")) }
    }

    fun toYouTube(a: Activity) = send(a, YT, "YouTube")
    fun toInstagram(a: Activity) = send(a, IG, "Instagram")

    fun notify(c: Context) {
        val yt = c.flag("plat_yt", true); val ig = c.flag("plat_ig", false)
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ar_done", "AutoReel done", NotificationManager.IMPORTANCE_HIGH))
        val b = Notification.Builder(c, "ar_done").setContentTitle("Video ready ✅").setSmallIcon(android.R.drawable.stat_sys_upload_done).setAutoCancel(true)
        fun pi(pkg: String, code: Int): PendingIntent? { val i = intent(c)?.setPackage(pkg) ?: return null; return PendingIntent.getActivity(c, code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT) }
        val ytP = if (yt) pi(YT, 2) else null; val igP = if (ig) pi(IG, 3) else null
        if (ytP == null && igP == null) return
        b.setContentText(if (ytP != null && igP != null) "Tap a button to upload" else "Tap to upload").setContentIntent(ytP ?: igP)
        if (ytP != null && igP != null) { b.addAction(Notification.Action.Builder(android.R.drawable.ic_menu_share, "YouTube", ytP).build()); b.addAction(Notification.Action.Builder(android.R.drawable.ic_menu_share, "Instagram", igP).build()) }
        nm.notify(2, b.build())
    }
}
