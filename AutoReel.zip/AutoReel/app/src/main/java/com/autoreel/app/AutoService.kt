package com.autoreel.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentUris
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.MediaStore
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import kotlin.math.abs

class StopEx : RuntimeException("stopped")

class AutoService : AccessibilityService() {
    companion object {
        @Volatile var inst: AutoService? = null
        @Volatile var running = false
        @Volatile var stopReq = false
    }
    override fun onServiceConnected() { inst = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(i: Intent?): Boolean { inst = null; hideBubble(); return super.onUnbind(i) }
    override fun onDestroy() { hideBubble(); super.onDestroy() }

    // ---------------------------------------------------------------- floating bubble
    private val ui = Handler(Looper.getMainLooper())
    private var bubble: LinearLayout? = null
    private var orbV: TextView? = null
    private var lblV: TextView? = null
    @Volatile private var barHidden = false
    private val bubbleTick = object : Runnable {
        override fun run() {
            if (bubble == null) return
            val s = Live.stage
            val el = if (Live.startedAt > 0) (System.currentTimeMillis() - Live.startedAt) / 1000 else 0L
            orbV?.text = if (s in 1..6) STAGES[s - 1].first else "⚡"
            lblV?.text = (if (s in 1..6) STAGES[s - 1].second else "Working") + " · " + (el / 60) + ":" + (el % 60).toString().padStart(2, '0')
            ui.postDelayed(this, 1000)
        }
    }

    private fun showBubble() {
        ui.post {
            if (bubble != null || barHidden || p().getString("bubble", "true") != "true") return@post
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            val row = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(4), dp(14), dp(4))
                background = shape(Color.parseColor("#F0100A20"), dp(30), PINK)
            }
            val orb = TextView(this).apply {
                text = "⚡"; textSize = 20f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(VIOLET, PINK)).apply { setShape(GradientDrawable.OVAL) }
            }
            val lbl = TextView(this).apply { text = "AutoReel"; textSize = 12f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; setPadding(dp(8), 0, 0, 0) }
            row.addView(orb, LinearLayout.LayoutParams(dp(46), dp(46)))
            row.addView(lbl, LinearLayout.LayoutParams(-2, -2))

            val menu = LinearLayout(this).apply {
                visibility = View.GONE; setPadding(dp(6), dp(6), dp(6), dp(6)); background = shape(Color.parseColor("#F0100A20"), dp(16), EDGE)
            }
            fun item(t: String, c: Int, a: () -> Unit) = TextView(this).apply {
                text = t; textSize = 13f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
                setPadding(dp(14), dp(10), dp(14), dp(10)); background = shape(c, dp(12)); setOnClickListener { a() }
            }
            val mp = { LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(3), 0, dp(3), 0) } }
            menu.addView(item("✕ Hide", Color.parseColor("#2A1F44")) { hideBubble(); barHidden = true }, mp())
            menu.addView(item("■ Stop", Color.parseColor("#B91C1C")) {
                stopRun(); hideBubble(); Toast.makeText(this, "Stopping AutoReel...", Toast.LENGTH_SHORT).show()
            }, mp())
            root.addView(row); root.addView(menu, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(6) })

            val wlp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(6); y = (resources.displayMetrics.heightPixels * 0.3).toInt() }

            var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
            orb.setOnTouchListener { _, ev ->
                when (ev.action) {
                    MotionEvent.ACTION_DOWN -> { sx = wlp.x; sy = wlp.y; dx = ev.rawX; dy = ev.rawY; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val mx = (ev.rawX - dx).toInt(); val my = (ev.rawY - dy).toInt()
                        if (abs(mx) > dp(6) || abs(my) > dp(6)) moved = true
                        if (moved) { wlp.x = sx + mx; wlp.y = sy + my; try { wm.updateViewLayout(root, wlp) } catch (_: Exception) {} }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) {
                        menu.visibility = if (menu.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                        if (menu.visibility == View.VISIBLE) ui.postDelayed({ menu.visibility = View.GONE }, 6000)
                    }
                }
                true
            }
            try { wm.addView(root, wlp) } catch (e: Exception) { return@post }
            bubble = root; orbV = orb; lblV = lbl
            ui.post(bubbleTick)
        }
    }

    private fun hideBubble() {
        ui.post {
            ui.removeCallbacks(bubbleTick)
            bubble?.let { try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (_: Exception) {} }
            bubble = null
        }
    }

    fun stopRun() { stopReq = true; Live.stage = 0 }

    // ---------------------------------------------------------------- helpers
    private fun say(s: String) = Pipeline.log(this, s)
    private fun bump(k: String) { val pr = p(); pr.edit().putInt(k, pr.getInt(k, 0) + 1).apply() }
    private fun nap(ms: Long) {
        var left = ms
        while (left > 0) { if (stopReq) throw StopEx(); val s = minOf(left, 250L); Thread.sleep(s); left -= s }
        if (stopReq) throw StopEx()
    }
    private fun nodes(): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) { if (n == null) return; out.add(n); for (i in 0 until n.childCount) walk(n.getChild(i)) }
        walk(rootInActiveWindow); return out
    }
    private fun label(n: AccessibilityNodeInfo) = ((n.text?.toString() ?: "") + " " + (n.contentDescription?.toString() ?: "")).trim()
    private fun texts() = nodes().map { label(it) }.filter { it.isNotEmpty() }
    private fun has(s: String) = texts().any { it.contains(s, true) }
    private fun find(vararg k: String): AccessibilityNodeInfo? {
        val all = nodes()
        return all.firstOrNull { n -> val l = label(n); k.any { l.equals(it, true) } } ?: all.firstOrNull { n -> val l = label(n); l.isNotEmpty() && k.any { l.contains(it, true) } }
    }
    private fun gesture(x1: Float, y1: Float, x2: Float, y2: Float): Boolean {
        val pa = Path().apply { moveTo(x1, y1); if (x1 != x2 || y1 != y2) lineTo(x2, y2) }
        val ok = dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(pa, 0, if (x1 == x2 && y1 == y2) 60 else 350)).build(), null, null)
        nap(700); return ok
    }
    private fun click(n: AccessibilityNodeInfo): Boolean {
        var c: AccessibilityNodeInfo? = n
        while (c != null && !c.isClickable) c = c.parent
        if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) { nap(700); return true }
        val r = Rect(); n.getBoundsInScreen(r); return gesture(r.centerX().toFloat(), r.centerY().toFloat(), r.centerX().toFloat(), r.centerY().toFloat())
    }
    private fun tap(vararg k: String): Boolean { val n = find(*k) ?: return false; return click(n) }
    private fun tapExact(vararg k: String): Boolean {
        val n = nodes().firstOrNull { x -> val l = label(x); k.any { l.equals(it, true) } } ?: return false
        return click(n)
    }
    private fun editors() = nodes().filter { it.isEditable }
    private fun setText(n: AccessibilityNodeInfo, t: String): Boolean {
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val b = Bundle(); b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t)
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }
    private fun waitFor(sec: Int, cond: () -> Boolean): Boolean { var i = 0; while (i++ < sec * 2) { if (cond()) return true; nap(500) }; return false }
    private fun launchPkg(pkg: String): Boolean {
        val i = packageManager.getLaunchIntentForPackage(pkg) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP); startActivity(i); return true
    }
    private fun swipeUp() { val d = resources.displayMetrics; gesture(d.widthPixels / 2f, d.heightPixels * 0.75f, d.widthPixels / 2f, d.heightPixels * 0.3f) }

    private fun gemSend(t: String): Boolean {
        var ok = waitFor(20) { editors().isNotEmpty() }
        if (!ok) { tap("Ask Gemini", "Enter a prompt"); ok = waitFor(10) { editors().isNotEmpty() } }
        if (!ok) { say("Gemini input box not found (is the Gemini app logged in?)"); return false }
        setText(editors().first(), t); nap(900)
        if (!tap("Send message", "Send")) { say("Gemini send button not found"); return false }
        return true
    }

    fun runAll() {
        if (running) return
        running = true; stopReq = false; barHidden = false
        showBubble()
        Thread {
            val wl = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP, "ar:run")
            wl.acquire(90 * 60 * 1000L)
            try { flow() }
            catch (e: StopEx) { say("■ Stopped by you") }
            catch (e: Exception) { say("ERROR: " + e.message) }
            finally {
                try { wl.release() } catch (_: Exception) {}
                running = false; Live.stage = 0; hideBubble(); stopReq = false
                try { launchPkg(packageName) } catch (_: Exception) {}
            }
        }.start()
    }

    private class M(val uri: Uri, val name: String)
    private fun latest(coll: Uri, since: Long): M? = try {
        contentResolver.query(coll, arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME), "${MediaStore.MediaColumns.DATE_ADDED} >= ?",
            arrayOf((since - 5).toString()), "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { c ->
            if (c.moveToFirst()) M(ContentUris.withAppendedId(coll, c.getLong(0)), c.getString(1) ?: "") else null }
    } catch (e: Exception) { null }
    private fun chrome(url: String) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage("com.android.chrome").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }

    // After Studio opens the Android file chooser: pick the newest item (photo picker grid) or the file by name (documents list).
    private fun pickLatest(kind: String, name: String?) {
        nap(3000)
        val item = nodes().firstOrNull { val l = label(it); l.startsWith(kind, true) || l.startsWith("Image", true) }
        if (item != null) {
            var c: AccessibilityNodeInfo? = item; while (c != null && !c.isClickable) c = c.parent
            if (c != null) c.performAction(AccessibilityNodeInfo.ACTION_CLICK) else { val r = Rect(); item.getBoundsInScreen(r); gesture(r.centerX().toFloat(), r.centerY().toFloat(), r.centerX().toFloat(), r.centerY().toFloat()) }
            nap(1200); tap("Add", "Done", "Select")
        } else if (name != null) { tap("Recent"); nap(1200); tap(name) }
        nap(2500)
    }

    // ---------------------------------------------------------------- thumbnails / toggles
    private fun makeThumb(prompt: String): M? {
        val since = System.currentTimeMillis() / 1000
        chrome("https://gemini.google.com/app"); nap(5000)
        var t: M? = null
        if (gemSend(prompt) && waitFor(240) { find("Download") != null }) {
            tap("Download image", "Download")
            waitFor(60) { t = latest(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, since); t != null }
        }
        return t
    }

    private fun firstCheckable(x: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (x == null) return null
        if (x.isCheckable) return x
        for (i in 0 until x.childCount) { val r = firstCheckable(x.getChild(i)); if (r != null) return r }
        return null
    }
    private fun switchFor(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var c: AccessibilityNodeInfo? = n
        var up = 0
        while (c != null && up < 4) { val s = firstCheckable(c); if (s != null) return s; c = c.parent; up++ }
        return null
    }
    // Finds the row with this text (scrolling down if needed) and puts its switch in the wanted position.
    private fun setToggle(text: String, want: Boolean): Boolean {
        for (n in 0..6) {
            val row = nodes().firstOrNull { label(it).contains(text, true) }
            if (row != null) {
                val sw = switchFor(row)
                if (sw == null) { say("Toggle not found: $text"); return false }
                if (sw.isChecked != want) click(sw)
                return true
            }
            swipeUp()
        }
        say("Option not found: $text"); return false
    }
    private fun onCaption() = editors().any { ((it.hintText?.toString() ?: "") + " " + label(it)).contains("caption", true) }
    private fun backToCaption() { for (n in 0..2) { if (onCaption()) return; performGlobalAction(GLOBAL_ACTION_BACK); nap(1500) } }

    private fun igCover(thumb: M): Boolean {
        if (!tap("Edit cover")) return false
        nap(3000)
        if (!tap("Add from camera roll", "Camera roll", "Add from gallery")) { say("Cover: gallery option not found, keeping auto cover"); backToCaption(); return false }
        pickLatest("Photo", thumb.name)
        tap("Done", "Next", "Save"); nap(2000)
        backToCaption()
        say("Cover set from the Gemini thumbnail"); return true
    }

    private fun igSettings(pr: android.content.SharedPreferences) {
        fun on(k: String, d: Boolean) = pr.getString(k, d.toString()) == "true"
        say("Instagram: applying reel settings...")
        setToggle("Add AI label", on("ig_ai", true))
        setToggle("Threads", on("ig_threads", true))
        setToggle("Facebook", on("ig_fb", false))
        setToggle("Your story", on("ig_story", false))
        if (!tap("More options")) { swipeUp(); tap("More options") }
        nap(2000)
        if (has("Upload at highest quality")) {
            setToggle("Upload at highest quality", on("ig_hq", true))
            setToggle("as a template", !on("ig_template", true))
            setToggle("download your reels", on("ig_download", true))
            performGlobalAction(GLOBAL_ACTION_BACK); nap(1500)
        } else say("Instagram 'More options' page not found")
    }

    // ---------------------------------------------------------------- main flow
    private fun flow() {
        val pr = p(); fun g(k: String) = pr.getString(k, "")!!.trim()
        val ytOn = pr.getString("plat_yt", "true") == "true"
        val igOn = pr.getString("plat_ig", "false") == "true"
        if (!ytOn && !igOn) { say("Select YouTube and/or Instagram first"); return }
        val started = System.currentTimeMillis() / 1000; Live.startedAt = System.currentTimeMillis(); Live.info = ""
        val niche = g("niche").ifEmpty { "trending" }
        val tagN = (g("hashtags").toIntOrNull() ?: 5).coerceIn(1, 15)
        val footer = g("footer")
        val retries = (g("retries").toIntOrNull() ?: 1).coerceIn(0, 3)
        val gap = (g("gap").toLongOrNull() ?: 15L).coerceIn(0L, 120L)
        val vis = g("yt_vis").ifEmpty { "Public" }
        val sec = g("seconds").let { if (it.isEmpty() || it == "Auto") 10 else it.toIntOrNull() ?: 10 }
        say("Platforms: " + listOfNotNull(if (ytOn) "YouTube" else null, if (igOn) "Instagram" else null).joinToString(" + "))

        Live.stage = 1; say("Researching this week's top viral videos in Chrome...")
        val seen = LinkedHashSet<String>()
        for (qy in listOf("$niche shorts", "$niche viral", "$niche trending today")) {
            chrome("https://m.youtube.com/results?search_query=" + URLEncoder.encode(qy, "UTF-8") + "&sp=CAMSBAgDEAE%253D")
            nap(7000)
            repeat(4) { texts().filter { it.length in 20..180 }.forEach { seen.add(it) }; swipeUp() }
        }
        val research = seen.take(60).joinToString("\n")

        Live.stage = 2; say("Gemini (Chrome): deep viral analysis, gaps, SEO and plan...")
        chrome("https://gemini.google.com/app"); nap(6000)
        val ask = "You are an elite short-form video strategist for YouTube Shorts and Instagram Reels, obsessed with real virality. " +
            "DATA: the most viewed videos this week in my niche (titles and views):\n$research\n\n" +
            "STEP 1 - DEEP ANALYSIS. Find what these videos share: hook type in the first 1 to 2 seconds, emotion trigger, pacing and cuts, on-screen text, sound or voice, loop ending, and why people share, save and comment. " +
            "Then find what is MISSING in all of them: overused formats, untouched angles, weak endings, audience pain points nobody serves. " +
            "STEP 2 - Invent ONE completely new original idea that uses the winning patterns and fills the biggest gap. Never copy any video. " +
            "STEP 3 - SEO like a pro: keyword-first title under 70 characters, description (first 2 lines keyword-rich, then a call to action), $tagN hashtags (mix of broad, mid-size and niche), and tags. Language: ${g("language")}. Style: ${g("style")}.\n" +
            "Reply with one JSON object with keys: analysis (max 4 short lines: the winning patterns), gap (one line: what is missing that my idea fills), title, description, ig_caption (Instagram caption: punchy hook line, 1 to 2 short lines, call to action, NO hashtags), hashtags (array), tags (one comma separated string under 400 characters), " +
            "veo_prompt (detailed cinematic video prompt for EXACTLY $sec seconds, vertical 9:16, with second-by-second beats: a shocking curiosity hook in the first 2 seconds, escalating middle, and a last second that loops back into the first; include camera, lighting, sound and one short spoken line), " +
            "thumbnail_prompt (YouTube thumbnail 16:9, bold high-contrast, 2 to 4 words of text), cover_prompt (Instagram Reel cover 9:16, one strong subject, 2 to 4 words of text kept in the center safe area). " +
            "After the JSON, on a new line, write the letters Z X Q E N D joined together with no spaces."
        if (!gemSend(ask)) return
        var last = ""; var same = 0
        if (!waitFor(420) { val j = texts().joinToString("\n"); if (j.contains("ZXQEND")) { if (j == last) same++ else same = 0; last = j; same >= 6 } else false }) { say("Gemini did not finish the plan"); return }
        val end0 = last.lastIndexOf("ZXQEND"); val b = last.lastIndexOf('}', end0); val a = last.lastIndexOf('{', b)
        val idea = try { JSONObject(last.substring(a, b + 1).replace("\n", " ")) } catch (e: Exception) { say("Could not read the plan JSON"); return }
        val hs = idea.optJSONArray("hashtags")
        val tl = if (hs == null) "" else (0 until minOf(hs.length(), tagN)).joinToString(" ") { hs.getString(it) }
        val title = idea.getString("title").take(95)
        val foot = if (footer.isNotEmpty()) "\n\n$footer" else ""
        val ytTl = if (tl.contains("#shorts", true)) tl else "$tl #Shorts"
        val desc = idea.optString("description") + foot + "\n\n" + ytTl
        val igCap = ((idea.optString("ig_caption").ifEmpty { title + "\n\n" + idea.optString("description") }) + foot + "\n\n" + tl).take(2000)
        pr.edit().putString("last_title", title).putString("last_desc", desc).apply()
        Live.info = "🎬 $title\n\n🧠 " + idea.optString("analysis") + "\n\n🕳 " + idea.optString("gap") + "\n\n" + tl; say("Plan: $title")

        Live.stage = 3; say("Gemini is making the ${sec}s video (few minutes)...")
        if (!gemSend("Create a video: " + idea.getString("veo_prompt") + " Exactly $sec seconds, vertical 9:16 portrait, 1080x1920, cinematic, with native audio.")) return
        if (!waitFor(900) { find("Download") != null }) { say("Video did not appear (Gemini Pro video limit?)"); return }
        tap("Download video", "Download")
        var vm: M? = null
        waitFor(150) { vm = latest(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, started); vm != null }
        val video = vm ?: run { say("Downloaded video not found. Allow media access, check Chrome downloads."); return }
        val f = File(filesDir, "v_${System.currentTimeMillis()}.mp4")
        try { contentResolver.openInputStream(video.uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }; pr.edit().putString("last_video", f.absolutePath).apply(); Live.video = f.absolutePath } catch (e: Exception) {}
        say("Video saved: " + video.name)

        Live.stage = 4
        var thumbYt: M? = null; var thumbIg: M? = null
        if (ytOn) {
            say("Gemini makes the YouTube thumbnail...")
            thumbYt = makeThumb("Create an image: " + idea.optString("thumbnail_prompt") + " YouTube thumbnail, 16:9, bold readable text, high contrast.")
            say(if (thumbYt != null) "YouTube thumbnail saved" else "No YouTube thumbnail, continuing without it")
        }
        if (igOn) {
            say("Gemini makes the Instagram cover...")
            thumbIg = makeThumb("Create an image: " + idea.optString("cover_prompt").ifEmpty { idea.optString("thumbnail_prompt") } + " Instagram Reel cover, vertical 9:16, bold readable text in the center, high contrast.")
            say(if (thumbIg != null) "Instagram cover saved" else "No Instagram cover, Instagram will pick one")
        }

        var ytDone = false; var igDone = false
        if (ytOn) {
            Live.stage = 5
            for (n in 0..retries) {
                if (n > 0) say("Retrying YouTube ($n/$retries)...")
                if (uploadYouTube(title, desc, idea.optString("tags").take(450), video, thumbYt, vis)) { ytDone = true; break }
            }
            bump(if (ytDone) "yt_ok" else "fail")
        }
        if (igOn) {
            if (ytOn && gap > 0) { say("Waiting ${gap}s before Instagram..."); nap(gap * 1000) }
            Live.stage = 6
            val local = if (f.exists() && f.length() > 0) f else null
            for (n in 0..retries) {
                if (n > 0) say("Retrying Instagram ($n/$retries)...")
                if (uploadInstagram(local, video, igCap, thumbIg)) { igDone = true; break }
            }
            bump(if (igDone) "ig_ok" else "fail")
        }
        say("Done. " + (if (ytOn) "YouTube " + (if (ytDone) "✅ " else "❌ ") else "") + (if (igOn) "Instagram " + (if (igDone) "✅" else "❌") else ""))
    }

    private fun uploadYouTube(title: String, desc: String, tagsCsv: String, video: M, thumb: M?, vis: String): Boolean {
        say("Uploading in YouTube Studio (Chrome, original quality)...")
        chrome("https://studio.youtube.com/channel/UC/videos/upload?d=ud"); nap(9000)
        if (find("Select files") == null) { tap("More options"); nap(900); tap("Desktop site"); nap(9000) }
        if (!waitFor(40) { find("Select files") != null }) { say("Studio upload page not ready. Log in to YouTube in Chrome and turn on Desktop site."); return false }
        tap("Select files"); pickLatest("Video", video.name)
        var tD = false; var dD = false; var tagD = false; var thumbD = thumb == null; var finished = false; var vizSince = 0L
        val stop = System.currentTimeMillis() + 40 * 60 * 1000L
        while (!finished && System.currentTimeMillis() < stop) {
            for (e in editors()) {
                val l = (e.hintText?.toString() ?: "") + " " + label(e)
                if (!tD && (l.contains("title", true) || l.contains("describes your video", true))) { setText(e, title); tD = true }
                else if (!dD && (l.contains("tell viewers", true) || l.contains("description", true))) { setText(e, desc); dD = true }
                else if (!tagD && l.contains("add tag", true)) { setText(e, tagsCsv); tagD = true }
            }
            if (tD && dD && !tagD) tap("Show more")
            if (tD && !thumbD && tap("Upload file")) { pickLatest("Photo", thumb?.name); thumbD = true }
            if (has("altered")) tap("Yes")
            tap("No, it's not made for kids", "not made for kids")
            val onViz = has("Save or publish") || (has("Unlisted") && has("Private") && has("Public"))
            if (onViz) {
                val now = System.currentTimeMillis(); if (vizSince == 0L) vizSince = now
                val ready = has("Finished processing") || (has("Checks complete") && now - vizSince > 180000)
                if (ready || now - vizSince > 15 * 60 * 1000L) {
                    val pick = if (vis == "Public" && !ready) "Unlisted" else vis
                    tap(pick); nap(900)
                    if (tap("Publish", "Save")) { finished = true; say(if (pick == "Public") "YouTube: published PUBLIC" else "YouTube: saved as $pick" + (if (vis == "Public") " (processing slow, make it Public later in Studio)" else "")) }
                }
            } else if (tD) tap("Next")
            nap(2000)
        }
        nap(4000); tap("Close")
        if (!finished) say("YouTube upload did not finish. Check Chrome.")
        return finished
    }

    private fun uploadInstagram(file: File?, video: M, caption: String, thumb: M?): Boolean {
        val pkg = "com.instagram.android"; val pr = p()
        say("Uploading Reel to Instagram...")
        if (packageManager.getLaunchIntentForPackage(pkg) == null) { say("Instagram app is not installed"); return false }
        val uri = if (file != null) FileProvider.getUriForFile(this, "com.autoreel.app.fp", file) else video.uri
        try { grantUriPermission(pkg, uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        try { (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("ig", caption)) } catch (_: Exception) {}
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"; putExtra(Intent.EXTRA_STREAM, uri); setPackage(pkg); clipData = ClipData.newRawUri("v", uri)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try { startActivity(i) } catch (e: Exception) { say("Could not open Instagram: " + e.message); return false }
        nap(6000)
        // If the share intent did not open the reel editor, go the manual way: + button, REEL tab, newest video.
        if (!waitFor(20) { has("Next") || onCaption() || has("Share to") }) {
            say("Instagram: using the + button route")
            launchPkg(pkg); nap(4000)
            tap("Create", "New post"); nap(2500)
            tapExact("REEL"); nap(2000)
            pickLatest("Video", video.name)
            tapExact("Next"); nap(3000)
        }
        var capDone = false; var coverDone = thumb == null; var optsDone = false; var shared = false
        val stop = System.currentTimeMillis() + 12 * 60 * 1000L
        while (!shared && System.currentTimeMillis() < stop) {
            tapExact("Got it", "OK", "Not now")
            if (!capDone) {
                if (has("Share to")) tapExact("Reel")
                val ed = editors().firstOrNull { ((it.hintText?.toString() ?: "") + " " + label(it)).contains("caption", true) }
                if (ed != null) { setText(ed, caption); ed.performAction(AccessibilityNodeInfo.ACTION_CLEAR_FOCUS); capDone = true; nap(1000) }
                else tapExact("Next")
            } else if (!coverDone) {
                coverDone = true
                if (thumb != null) try { igCover(thumb) } catch (e: StopEx) { throw e } catch (e: Exception) { say("Cover step failed: " + e.message) }
            } else if (!optsDone) {
                optsDone = true
                try { igSettings(pr) } catch (e: StopEx) { throw e } catch (e: Exception) { say("Settings step failed: " + e.message) }
            } else {
                if (tapExact("Share")) shared = true else tapExact("Next")
            }
            nap(2000)
        }
        if (!shared) { say("Instagram upload did not finish. Check the Instagram app (caption is copied)."); return false }
        nap(6000)
        waitFor(240) { !(has("Sharing") || has("Uploading") || has("Posting")) }
        say("Instagram: Reel shared")
        return true
    }
}
