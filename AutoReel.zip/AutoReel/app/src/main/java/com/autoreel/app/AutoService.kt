package com.autoreel.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ContentUris
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.MediaStore
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder

class AutoService : AccessibilityService() {
    companion object { @Volatile var inst: AutoService? = null; @Volatile var running = false }
    override fun onServiceConnected() { inst = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(i: Intent?): Boolean { inst = null; return super.onUnbind(i) }

    private fun say(s: String) = Pipeline.log(this, s)
    private fun nodes(): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) { if (n == null) return; out.add(n); for (i in 0 until n.childCount) walk(n.getChild(i)) }
        walk(rootInActiveWindow); return out
    }
    private fun label(n: AccessibilityNodeInfo) = ((n.text?.toString() ?: "") + " " + (n.contentDescription?.toString() ?: "")).trim()
    private fun texts() = nodes().map { label(it) }.filter { it.isNotEmpty() }
    private fun has(s: String) = texts().any { it.contains(s, true) }
    private fun find(vararg k: String): AccessibilityNodeInfo? {
        val all = nodes()
        return all.firstOrNull { n -> val l = label(n); k.any { l.equals(it, true) } } ?: all.firstOrNull { n -> val l = label(n); l.isNotEmpty() && k.any { l.contains(it, true) } }
    }
    private fun gesture(x1: Float, y1: Float, x2: Float, y2: Float): Boolean {
        val p = Path().apply { moveTo(x1, y1); if (x1 != x2 || y1 != y2) lineTo(x2, y2) }
        val ok = dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, if (x1 == x2 && y1 == y2) 60 else 350)).build(), null, null)
        Thread.sleep(700); return ok
    }
    private fun tap(vararg k: String): Boolean {
        val n = find(*k) ?: return false
        var c: AccessibilityNodeInfo? = n
        while (c != null && !c.isClickable) c = c.parent
        if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) { Thread.sleep(700); return true }
        val r = Rect(); n.getBoundsInScreen(r); return gesture(r.centerX().toFloat(), r.centerY().toFloat(), r.centerX().toFloat(), r.centerY().toFloat())
    }
    private fun editors() = nodes().filter { it.isEditable }
    private fun setText(n: AccessibilityNodeInfo, t: String): Boolean {
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val b = Bundle(); b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t)
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }
    private fun waitFor(sec: Int, cond: () -> Boolean): Boolean { var i = 0; while (i++ < sec * 2) { if (cond()) return true; Thread.sleep(500) }; return false }
    private fun launchPkg(pkg: String): Boolean {
        val i = packageManager.getLaunchIntentForPackage(pkg) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP); startActivity(i); return true
    }
    private fun swipeUp() { val d = resources.displayMetrics; gesture(d.widthPixels / 2f, d.heightPixels * 0.75f, d.widthPixels / 2f, d.heightPixels * 0.3f) }
    private fun latestVideo(since: Long): Uri? = try {
        contentResolver.query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, arrayOf(MediaStore.Video.Media._ID), "${MediaStore.Video.Media.DATE_ADDED} >= ?",
            arrayOf((since - 5).toString()), "${MediaStore.Video.Media.DATE_ADDED} DESC")?.use { c ->
            if (c.moveToFirst()) ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, c.getLong(0)) else null }
    } catch (e: Exception) { null }

    private fun gemSend(t: String): Boolean {
        var ok = waitFor(20) { editors().isNotEmpty() }
        if (!ok) { tap("Ask Gemini", "Enter a prompt"); ok = waitFor(10) { editors().isNotEmpty() } }
        if (!ok) { say("Gemini input box not found (is the Gemini app logged in?)"); return false }
        setText(editors().first(), t); Thread.sleep(900)
        if (!tap("Send message", "Send")) { say("Gemini send button not found"); return false }
        return true
    }

    fun runAll() {
        if (running) return; running = true
        Thread {
            val wl = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP, "ar:run")
            wl.acquire(45 * 60 * 1000L)
            try { flow() } catch (e: Exception) { say("ERROR: " + e.message) }
            finally { wl.release(); running = false; Live.stage = 0; launchPkg(packageName) }
        }.start()
    }

    private class M(val uri: Uri, val name: String)
    private fun latest(coll: Uri, since: Long): M? = try {
        contentResolver.query(coll, arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME), "${MediaStore.MediaColumns.DATE_ADDED} >= ?",
            arrayOf((since - 5).toString()), "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { c ->
            if (c.moveToFirst()) M(ContentUris.withAppendedId(coll, c.getLong(0)), c.getString(1) ?: "") else null }
    } catch (e: Exception) { null }
    private fun chrome(url: String) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage("com.android.chrome").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }

    // After Studio opens the Android file chooser: pick the newest item (photo picker grid) or the file by name (documents list).
    private fun pickLatest(kind: String, name: String?) {
        Thread.sleep(3000)
        val item = nodes().firstOrNull { val l = label(it); l.startsWith(kind, true) || l.startsWith("Image", true) }
        if (item != null) {
            var c: AccessibilityNodeInfo? = item; while (c != null && !c.isClickable) c = c.parent
            if (c != null) c.performAction(AccessibilityNodeInfo.ACTION_CLICK) else { val r = Rect(); item.getBoundsInScreen(r); gesture(r.centerX().toFloat(), r.centerY().toFloat(), r.centerX().toFloat(), r.centerY().toFloat()) }
            Thread.sleep(1200); tap("Add", "Done", "Select")
        } else if (name != null) { tap("Recent"); Thread.sleep(1200); tap(name) }
        Thread.sleep(2500)
    }

    private fun flow() {
        val p = p(); fun g(k: String) = p.getString(k, "")!!.trim()
        val started = System.currentTimeMillis() / 1000; Live.startedAt = System.currentTimeMillis()
        val niche = g("niche").ifEmpty { "trending" }

        Live.stage = 1; say("1/5 Researching this week's top viral videos in Chrome...")
        val seen = LinkedHashSet<String>()
        for (qy in listOf("$niche shorts", "$niche viral")) {
            chrome("https://m.youtube.com/results?search_query=" + URLEncoder.encode(qy, "UTF-8") + "&sp=CAMSBAgDEAE%253D")
            Thread.sleep(7000)
            repeat(3) { texts().filter { it.length in 20..180 }.forEach { seen.add(it) }; swipeUp() }
        }
        val research = seen.take(40).joinToString("\n")

        Live.stage = 2; say("2/5 Gemini (Chrome): research, SEO and plan...")
        chrome("https://gemini.google.com/app"); Thread.sleep(6000)
        val ask = "You are a top YouTube Shorts growth strategist. These videos are the most viewed this week in my niche (titles and views):\n$research\n\n" +
            "1) Analyze why they went viral: hook in the first 2 seconds, emotion, pacing, loop. 2) Invent ONE completely new original idea using those principles, never a copy. " +
            "3) Do SEO like a pro creator: keyword-first title under 70 characters, description (first 2 lines keyword-rich, then a call to action), 3 strong hashtags, and tags. Language: ${g("language")}. Style: ${g("style")}.\n" +
            "Reply with one JSON object with keys: title, description, hashtags (array), tags (one comma separated string under 400 characters), veo_prompt (detailed cinematic ${g("seconds")} second vertical video prompt with a very strong hook in the first 2 seconds), thumbnail_prompt (bold high-contrast thumbnail idea with 2 to 4 words of text). " +
            "After the JSON, on a new line, write the letters Z X Q E N D joined together with no spaces."
        if (!gemSend(ask)) return
        var last = ""; var same = 0
        if (!waitFor(360) { val j = texts().joinToString("\n"); if (j.contains("ZXQEND")) { if (j == last) same++ else same = 0; last = j; same >= 6 } else false }) { say("Gemini did not finish the plan"); return }
        val end0 = last.lastIndexOf("ZXQEND"); val b = last.lastIndexOf('}', end0); val a = last.lastIndexOf('{', b)
        val idea = try { JSONObject(last.substring(a, b + 1).replace("\n", " ")) } catch (e: Exception) { say("Could not read the plan JSON"); return }
        val tags = idea.optJSONArray("hashtags"); val tl = if (tags == null) "" else (0 until tags.length()).joinToString(" ") { tags.getString(it) }
        val title = idea.getString("title").take(95); val desc = idea.optString("description") + "\n\n" + tl
        p.edit().putString("last_title", title).putString("last_desc", desc).apply()
        Live.info = "🎬 $title\n\n$tl"; say("Plan: $title")

        Live.stage = 3; say("3/5 Gemini is making the video (few minutes)...")
        if (!gemSend("Create a video: " + idea.getString("veo_prompt") + " Vertical 9:16.")) return
        if (!waitFor(900) { find("Download") != null }) { say("Video did not appear (Gemini Pro video limit?)"); return }
        tap("Download video", "Download")
        var vm: M? = null
        waitFor(150) { vm = latest(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, started); vm != null }
        val video = vm ?: run { say("Downloaded video not found. Allow media access, check Chrome downloads."); return }
        val f = File(filesDir, "v_${System.currentTimeMillis()}.mp4")
        try { contentResolver.openInputStream(video.uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }; p.edit().putString("last_video", f.absolutePath).apply(); Live.video = f.absolutePath } catch (e: Exception) {}
        say("Video saved: " + video.name)

        Live.stage = 4; say("4/5 Gemini makes the thumbnail...")
        chrome("https://gemini.google.com/app"); Thread.sleep(5000)
        var thumb: M? = null
        if (gemSend("Create an image: " + idea.optString("thumbnail_prompt") + " YouTube thumbnail, 16:9, bold readable text, high contrast.") && waitFor(240) { find("Download") != null }) {
            tap("Download image", "Download")
            waitFor(60) { thumb = latest(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, started); thumb != null }
        }
        say(if (thumb != null) "Thumbnail saved" else "No thumbnail, continuing without it")

        Live.stage = 5; say("5/5 Uploading in YouTube Studio (Chrome, original quality)...")
        chrome("https://studio.youtube.com/channel/UC/videos/upload?d=ud"); Thread.sleep(9000)
        if (find("Select files") == null) { tap("More options"); Thread.sleep(900); tap("Desktop site"); Thread.sleep(9000) }
        if (!waitFor(40) { find("Select files") != null }) { say("Studio upload page not ready. Log in to YouTube in Chrome and turn on Desktop site."); return }
        tap("Select files"); pickLatest("Video", video.name)
        var tD = false; var dD = false; var tagD = false; var thumbD = thumb == null; var finished = false; var vizSince = 0L
        val stop = System.currentTimeMillis() + 40 * 60 * 1000L
        while (!finished && System.currentTimeMillis() < stop) {
            for (e in editors()) {
                val l = (e.hintText?.toString() ?: "") + " " + label(e)
                if (!tD && (l.contains("title", true) || l.contains("describes your video", true))) { setText(e, title); tD = true }
                else if (!dD && (l.contains("tell viewers", true) || l.contains("description", true))) { setText(e, desc); dD = true }
                else if (!tagD && l.contains("add tag", true)) { setText(e, idea.optString("tags").take(450)); tagD = true }
            }
            if (tD && dD && !tagD) tap("Show more")
            if (tD && !thumbD && tap("Upload file")) { pickLatest("Photo", thumb?.name); thumbD = true }
            if (has("altered")) tap("Yes")
            tap("No, it's not made for kids", "not made for kids")
            val onViz = has("Save or publish") || (has("Unlisted") && has("Private") && has("Public"))
            if (onViz) {
                val now = System.currentTimeMillis(); if (vizSince == 0L) vizSince = now
                val ready = has("Finished processing") || (has("Checks complete") && now - vizSince > 180000)
                if (ready || now - vizSince > 15 * 60 * 1000L) {
                    tap(if (ready) "Public" else "Unlisted"); Thread.sleep(900)
                    if (tap("Publish", "Save")) { finished = true; say(if (ready) "Published PUBLIC after processing" else "Saved UNLISTED (processing slow). Make it Public later in Studio.") }
                }
            } else if (tD) tap("Next")
            Thread.sleep(2000)
        }
        Thread.sleep(4000); tap("Close")
        if (!finished) say("Upload did not finish. Check Chrome.")
        Live.stage = 6
    }
}
