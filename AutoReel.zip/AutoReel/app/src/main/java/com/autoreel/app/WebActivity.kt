package com.autoreel.app

import android.app.Activity
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.view.WindowManager
import android.webkit.*
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class WebActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var status: TextView
    private val h = Handler(Looper.getMainLooper())
    private val buf = StringBuilder()
    private var gen = 0

    private fun say(s: String) { runOnUiThread { status.text = s }; Pipeline.log(this, s) }
    private fun js(code: String, cb: (String) -> Unit = {}) = web.evaluateJavascript(code) { cb(it ?: "null") }
    private fun q(s: String) = JSONObject.quote(s)
    private fun later(ms: Long, f: () -> Unit) { val id = gen; h.postDelayed({ if (id == gen) f() }, ms) }
    private fun until(cond: String, secs: Int, cb: (Boolean) -> Unit) {
        var left = secs; val id = gen
        val r = object : Runnable { override fun run() {
            if (id != gen) return
            js("(function(){try{return !!($cond)}catch(e){return false}})()") { v -> if (v == "true") cb(true) else if (--left <= 0) cb(false) else h.postDelayed(this, 1000) }
        } }
        h.post(r)
    }
    private fun typeInto(sel: String, text: String) = js("(function(){var e=document.querySelector(${q(sel)});if(!e)return;e.focus();document.execCommand('selectAll');document.execCommand('insertText',false,${q(text)});})()")
    private fun click(sel: String) = js("(function(){var e=document.querySelector(${q(sel)});if(e)e.click();})()")
    private fun go(url: String, then: () -> Unit) {
        web.webViewClient = object : WebViewClient() { override fun onPageFinished(v: WebView, u: String) { web.webViewClient = WebViewClient(); then() } }
        web.loadUrl(url)
    }

    private val INPUT = "rich-textarea .ql-editor,div[contenteditable='true']"
    private fun gemSend(text: String, then: () -> Unit) {
        until("document.querySelector(\"$INPUT\")", 30) { ok ->
            if (!ok) { say("Gemini box not found. Log in to Google first."); return@until }
            typeInto(INPUT, text)
            later(1000) { click("button.send-button,button[aria-label*='Send']"); later(2000, then) }
        }
    }
    private fun waitReply(cb: (String) -> Unit) {
        var last = ""; var same = 0; var tries = 0; val id = gen
        val r = object : Runnable { override fun run() {
            if (id != gen) return
            js("(function(){var m=document.querySelectorAll('message-content');return m.length?m[m.length-1].innerText:''})()") { v ->
                val t = try { JSONArray("[$v]").getString(0) } catch (e: Exception) { "" }
                if (t.isNotEmpty() && t == last) same++ else same = 0
                last = t
                if (same >= 3) cb(t) else if (++tries > 150) say("Gemini did not answer in time") else h.postDelayed(this, 2000)
            }
        } }
        h.postDelayed(r, 3000)
    }

    private fun story() {
        val p = p(); Live.startedAt = System.currentTimeMillis()
        say("1/3 Gemini is writing the idea...")
        val niche = p.getString("niche", "")!!.ifEmpty { "any trending topic" }
        val ask = "You are a viral short-video strategist. Language: ${p.getString("language", "Hindi")}. Niche: $niche. Style: ${p.getString("style", "")}. " +
            "Think of what is going viral on YouTube right now in this niche, then invent ONE new original video idea. Reply with ONLY a JSON object: " +
            "{\"title\":\"catchy under 80 chars\",\"description\":\"2-3 lines plus call to action\",\"hashtags\":[\"#a\",\"#b\"],\"veo_prompt\":\"detailed cinematic ${p.getString("seconds", "8")} second video prompt\"}"
        go("https://gemini.google.com/app") { gemSend(ask) { waitReply { t ->
            try {
                val idea = JSONObject(t.substring(t.indexOf('{'), t.lastIndexOf('}') + 1))
                val tags = idea.getJSONArray("hashtags"); val tl = (0 until tags.length()).joinToString(" ") { tags.getString(it) }
                p.edit().putString("last_title", idea.getString("title") + " #Shorts").putString("last_desc", idea.getString("description") + "\n\n" + tl).putString("veo", idea.getString("veo_prompt")).apply()
                video()
            } catch (e: Exception) { say("Could not read the idea: " + e.message) }
        } } }
    }

    private fun video() {
        say("2/3 Gemini is making the video (few minutes)...")
        val p = p()
        gemSend("Create a video: " + p.getString("veo", "") + " Vertical 9:16.") {
            until("Array.from(document.querySelectorAll('video')).some(function(v){return v.currentSrc||v.src})", 900) { ok ->
                if (!ok) { say("No video appeared. Check Gemini screen (Pro limit?)."); return@until }
                later(3000) {
                    js("(function(){var v=Array.from(document.querySelectorAll('video')).pop();fetch(v.currentSrc||v.src).then(function(r){return r.blob()}).then(function(b){var f=new FileReader();f.onload=function(){var s=f.result.split(',')[1];for(var i=0;i<s.length;i+=400000)Android.chunk(s.substring(i,i+400000));Android.done();};f.readAsDataURL(b);}).catch(function(e){Android.fail(''+e)});})()")
                }
            }
        }
    }

    private fun upload() {
        val p = p(); val title = p.getString("last_title", "")!!; val desc = p.getString("last_desc", "")!!
        say("3/3 Uploading to YouTube Studio...")
        go("https://studio.youtube.com/channel/UC/videos/upload?d=ud") {
            until("document.querySelector('#select-files-button')", 40) { ok ->
                if (!ok) { say("YouTube Studio not ready. Log in first."); return@until }
                click("#select-files-button")
                until("document.querySelector('#title-textarea #textbox')", 90) { ok2 ->
                    if (!ok2) { say("Upload dialog did not open"); return@until }
                    later(1500) {
                        typeInto("#title-textarea #textbox", title.take(100)); typeInto("#description-textarea #textbox", desc)
                        later(1000) {
                            click("[name='VIDEO_MADE_FOR_KIDS_NOT_MFK']")
                            var n = 0
                            fun next() {
                                if (n++ < 3) { click("#next-button"); later(2000) { next() } }
                                else { click("[name='PRIVATE']"); later(1500) { click("#done-button"); say("Done. Uploaded as PRIVATE, check YouTube Studio") } }
                            }
                            later(1000) { next() }
                        }
                    }
                }
            }
        }
    }

    inner class Bridge {
        @JavascriptInterface fun chunk(s: String) { buf.append(s) }
        @JavascriptInterface fun done() {
            try {
                val f = File(filesDir, "v_${System.currentTimeMillis()}.mp4"); f.writeBytes(Base64.decode(buf.toString(), Base64.DEFAULT)); buf.setLength(0)
                p().edit().putString("last_video", f.absolutePath).apply(); Live.video = f.absolutePath
                runOnUiThread { say("Video saved (${f.length() / 1024} KB)"); upload() }
            } catch (e: Exception) { say("Save failed: " + e.message) }
        }
        @JavascriptInterface fun fail(m: String) { say("Video download failed: $m") }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); window.statusBarColor = BG
        web = WebView(this)
        web.settings.apply { javaScriptEnabled = true; domStorageEnabled = true; mediaPlaybackRequiresUserGesture = false }
        CookieManager.getInstance().apply { setAcceptCookie(true); setAcceptThirdPartyCookies(web, true) }
        web.webViewClient = WebViewClient(); web.addJavascriptInterface(Bridge(), "Android")
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, fc: FileChooserParams): Boolean {
                val f = File(p().getString("last_video", "")!!)
                cb.onReceiveValue(if (f.exists()) arrayOf(Uri.fromFile(f)) else null); return true
            }
        }
        status = TextView(this).apply { setTextColor(Color.WHITE); setPadding(dp(10), dp(6), dp(10), dp(6)); text = "Web mode: 1) Login 2) AUTO"; textSize = 12f }
        fun bt(t: String, a: () -> Unit) = Button(this).apply { text = t; textSize = 11f; setOnClickListener { gen++; a() } }
        val bar = LinearLayout(this)
        bar.addView(bt("Login") { web.loadUrl("https://accounts.google.com/ServiceLogin?service=youtube&continue=https://www.youtube.com") }, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(bt("Gemini") { web.loadUrl("https://gemini.google.com/app") }, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(bt("Studio") { web.loadUrl("https://studio.youtube.com") }, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(bt("▶ AUTO") { story() }, LinearLayout.LayoutParams(0, -2, 1.2f))
        bar.addView(bt("■") { say("Stopped") }, LinearLayout.LayoutParams(0, -2, 0.6f))
        setContentView(LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG); setPadding(0, dp(30), 0, 0); addView(bar); addView(status); addView(web, LinearLayout.LayoutParams(-1, 0, 1f)) })
    }

    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }
    override fun onPause() { super.onPause(); CookieManager.getInstance().flush() }
}
